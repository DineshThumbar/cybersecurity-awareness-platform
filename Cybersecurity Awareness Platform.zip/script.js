    const burger = document.querySelector('.burger');
const nav = document.querySelector('.nav-links');

burger.addEventListener('click', () => {
    nav.classList.toggle('nav-active');
    
    // Animate Burger
    burger.classList.toggle('toggle');
});





function showHeadlines(headline) {
      document.getElementById("content").innerHTML = "<h2>" + headline + "</h2><p>Yeh hai " + headline + " ka content...</p>";
    }
    
    
    
    
    
    
    
    
    function checkAnswers() {
    // Correct answers
    const correctAnswers = [
        "phishing", // Q1
        "to block unauthorized access", // Q2
        "A virus requires a host file to spread, whereas a worm is self-replicating", // Q3
        "An SQL Injection attack exploits a vulnerability in an application's software by manipulating SQL queries", // Q4
        "A secure password is a combination of upper/lowercase letters, numbers, and symbols", // Q5
        "A Zero-Day vulnerability is a flaw in software that is unknown to the software maker or antivirus vendors", // Q6
        "2FA adds an extra layer of security by requiring a second form of verification, such as a code sent to your phone" // Q7
    ];

    for (let i = 1; i <= 7; i++) {
        const userAnswer = document.getElementById(`answer${i}`).value.trim().toLowerCase();
        const feedback = document.getElementById(`feedback${i}`);

        if (userAnswer === correctAnswers[i - 1]) {
            feedback.textContent = "Correct!";
            feedback.classList.add('correct');
            feedback.classList.remove('wrong');
        } else {
            feedback.textContent = "Wrong! The correct answer is: " + correctAnswers[i - 1];
            feedback.classList.add('wrong');
            feedback.classList.remove('correct');
        }
    }
}
